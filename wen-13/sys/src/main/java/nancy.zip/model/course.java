package nancy.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @ClassName course
 * @Description TODO
 * @Author DELL
 * @Data 2020/7/1 11:20
 * @Version 1.0
 **/
@Getter
@Setter
@ToString
public class course {
    private int id;
    private String name;
    private int credit;
}
