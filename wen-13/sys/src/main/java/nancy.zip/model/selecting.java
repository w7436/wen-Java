package nancy.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @ClassName selecting
 * @Description TODO
 * @Author DELL
 * @Data 2020/7/1 15:29
 * @Version 1.0
 **/

@Getter
@Setter
@ToString
public class selecting {
    private int s_Id;
    private int c_Id;
    private int score;
}
