package nancy.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @ClassName teacher
 * @Description TODO
 * @Author DELL
 * @Data 2020/7/1 11:17
 * @Version 1.0
 **/
@Setter
@Getter
@ToString
public class teacher {
    private int id;
    private String name;
    private String sex;
    private String password;
    private String task;
    private String phone;
    private String email;
}
