package nancy.exception;

/**
 * @ClassName SystemException
 * @Description TODO
 * @Author DELL
 * @Data 2020/6/17 9:54
 * @Version 1.0
 **/
public class BaseException extends RuntimeException {

    public BaseException(Throwable cause, String message) {
        super(message);
    }
}
