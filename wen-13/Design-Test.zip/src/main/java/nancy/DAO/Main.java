package nancy.DAO;

import nancy.modol.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName Main
 * @Description TODO
 * @Author DELL
 * @Data 2020/6/17 10:30
 * @Version 1.0
 **/
public class Main {
    public static void main(String[] args) {

        //添加数据
//        Student stu = new Student();
//        stu.setId(3);
//        stu.setName("小黄");
//        stu.setDepartment("数学系");
//        stu.setScore(97);
//        boolean t = StuDao.insert(stu);
//        if(t == true) System.out.println("插入数据成功");


        //删除数据
//        int[] ids = {1};
//        boolean t1 = StuDao.delete(ids);
//        if(t1 == true){
//            System.out.println("删除数据成功");
//        }
//
        //修改学生信息
//        Student stu = new Student();
//        stu.setId(3);
//        stu.setName("小红");
//        stu.setDepartment("数学系");
//        stu.setScore(97);
//        boolean t2 = StuDao.update(stu);
//        if(t2 == true) System.out.println("修改信息成功");

        //查询ID信息
//        Student student2 = StuDao.query(2);
//        System.out.println(student2);

        //查询
//        Student student3 = StuDao.query("小红");
//        System.out.println(student3);

        //根据成绩区段进行查询
//        List<Student> l = new ArrayList<Student>();
//        l = StuDao.query();
//        for (int i = 0;i < l.size();i++){
//            System.out.println(l.get(i));
//        }


        //不同的系成绩排序查询
        List<Student> l = new ArrayList<Student>();
        l = StuDao.query1();
        for (int i = 0;i < l.size();i++){
            System.out.println(l.get(i));
        }

    }

}
